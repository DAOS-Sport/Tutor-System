/**
 * 手動扣課（F-R02 extension；獨立於 F-M05 扣課復活）
 *
 * 正式堂數真相是 course_sessions + checkin_records，而不是只遞增一個計數器。
 * 本路由在同一 transaction 建立 completed session、簽到、append-only ledger 與
 * admin audit；course_periods/admin_enrollments 的 used_sessions 只同步作相容顯示。
 */
const express = require('express');
const { randomUUID } = require('crypto');
const { pool } = require('../../models/db');
const {
  requireAdminAuth,
  requireAdminRole,
  getScopedVenueIds,
  isVenueInScope,
} = require('../../middlewares/adminAuth');

const router = express.Router();
const STRICT_UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function text(value, max = 1000) {
  return String(value == null ? '' : value).trim().slice(0, max);
}

function requestId(value) {
  const supplied = text(value, 128);
  return supplied || randomUUID();
}

function publicRow(row) {
  if (!row) return null;
  return {
    id: row.id,
    request_id: row.request_id,
    course_period_id: row.course_period_id,
    admin_enrollment_id: row.admin_enrollment_id || null,
    course_session_id: row.course_session_id,
    student_id: row.student_id,
    student_name: row.student_name || null,
    venue_id: row.venue_id,
    quantity: Number(row.quantity) || 1,
    remaining_before: Number(row.remaining_before),
    remaining_after: Number(row.remaining_after),
    reason: row.reason,
    deducted_by: row.deducted_by,
    created_at: row.created_at,
  };
}

async function readDeduction(client, periodId, id) {
  const r = await client.query(
    `SELECT d.*, s.name AS student_name
       FROM manual_lesson_deductions d
       LEFT JOIN students s ON s.id = d.student_id
      WHERE d.course_period_id = $1 AND d.id = $2`,
    [periodId, id]
  );
  return publicRow(r.rows[0]);
}

/**
 * GET /api/admin/manual-deductions?search=<報名單號/家長/學員/電話>
 * 只回可扣的 active course_period，且場館裁判與所有其他 admin route 共用。
 */
router.get('/', requireAdminAuth, requireAdminRole('admin', 'manager', 'staff'), async (req, res) => {
  try {
    const q = text(req.query.search || req.query.q, 120);
    if (q.length < 2) return res.json([]);

    const scope = getScopedVenueIds(req);
    const args = [`%${q.toLowerCase()}%`];
    const where = [
      `cp.status = 'active'`,
      `(
        LOWER(COALESCE(ae.id, '')) LIKE $1
        OR LOWER(COALESCE(ae.parent_name, '')) LIKE $1
        OR COALESCE(ae.parent_phone, '') LIKE $1
        OR EXISTS (
          SELECT 1
            FROM course_period_enrollments cpe_s
            JOIN students s_s ON s_s.id = cpe_s.student_id
           WHERE cpe_s.course_period_id = cp.id
             AND cpe_s.status = 'active'
             AND LOWER(s_s.name) LIKE $1
        )
      )`,
    ];
    if (scope) {
      args.push(scope);
      where.push(`cp.venue_id = ANY($${args.length}::text[])`);
    }

    const r = await pool.query(
      `SELECT cp.id AS course_period_id,
              cp.admin_enrollment_id,
              cp.venue_id,
              COALESCE(NULLIF(av.name, ''), v.name, cp.venue_id) AS venue_name,
              cp.course_type,
              cp.group_order_id,
              cp.total_sessions,
              cp.used_sessions AS stored_used_sessions,
              ae.parent_name,
              ae.parent_phone,
              ae.coach,
              ae.id AS enrollment_id,
              COALESCE(session_usage.attended_sessions, 0)::int AS used_sessions,
              COALESCE(session_usage.reserved_sessions, 0)::int AS reserved_sessions,
              GREATEST(cp.total_sessions - COALESCE(session_usage.reserved_sessions, 0), 0)::int AS remaining_sessions,
              COALESCE(members.students, '[]'::jsonb) AS students,
              COALESCE(member_count.active_student_count, 0)::int AS active_student_count
         FROM course_periods cp
    LEFT JOIN admin_enrollments ae ON ae.id = cp.admin_enrollment_id
    LEFT JOIN venues v ON v.id = cp.venue_id
    LEFT JOIN admin_venues av ON av.id = cp.venue_id
    LEFT JOIN LATERAL (
      SELECT
        COUNT(DISTINCT cs.id) FILTER (WHERE cs.status::text NOT LIKE 'cancelled%')::int AS reserved_sessions,
        COUNT(DISTINCT cs.id) FILTER (
          WHERE cs.status::text NOT LIKE 'cancelled%'
            AND cr.course_session_id IS NOT NULL
        )::int AS attended_sessions
        FROM course_sessions cs
   LEFT JOIN checkin_records cr ON cr.course_session_id = cs.id
       WHERE cs.course_period_id = cp.id
    ) session_usage ON TRUE
    LEFT JOIN LATERAL (
      SELECT jsonb_agg(jsonb_build_object('id', s.id, 'name', s.name) ORDER BY s.name) AS students
        FROM course_period_enrollments cpe
        JOIN students s ON s.id = cpe.student_id
       WHERE cpe.course_period_id = cp.id AND cpe.status = 'active'
    ) members ON TRUE
    LEFT JOIN LATERAL (
      SELECT COUNT(*)::int AS active_student_count
        FROM course_period_enrollments cpe_count
       WHERE cpe_count.course_period_id = cp.id AND cpe_count.status = 'active'
    ) member_count ON TRUE
        WHERE ${where.join(' AND ')}
        ORDER BY cp.created_at DESC
        LIMIT 50`,
      args
    );

    res.json(r.rows.map((row) => ({
      course_period_id: row.course_period_id,
      admin_enrollment_id: row.admin_enrollment_id || row.enrollment_id || null,
      venue_id: row.venue_id,
      venue_name: row.venue_name || row.venue_id,
      course_type: Number(row.course_type) || null,
      parent_name: row.parent_name || '',
      parent_phone: row.parent_phone || '',
      coach: row.coach || '',
      total_sessions: Number(row.total_sessions) || 0,
      used_sessions: Number(row.used_sessions) || 0,
      reserved_sessions: Number(row.reserved_sessions) || 0,
      remaining_sessions: Number(row.remaining_sessions) || 0,
      students: Array.isArray(row.students) ? row.students : [],
      // 團購／共享課期以「同一個 session 對所有成員」計堂；不能把單一學員的
      // 手動補登誤寫成新的共用 session，否則會扣到其他家庭。請走既有 F-R03
      // 簽到流程，直到有明確的整班扣課資料契約。
      is_shared_period: !!row.group_order_id || Number(row.active_student_count) > 1,
    })));
  } catch (err) {
    console.error('[admin/manual-deductions list]', err);
    res.status(500).json({ error: 'load manual deduction candidates failed' });
  }
});

/**
 * POST /api/admin/manual-deductions
 * { course_period_id, student_id, reason, request_id?, occurred_at? }
 */
router.post('/', requireAdminAuth, requireAdminRole('admin', 'manager', 'staff'), async (req, res) => {
  const body = req.body || {};
  const periodId = text(body.course_period_id, 64);
  const studentId = text(body.student_id, 64);
  const reason = text(body.reason, 1000);
  const idempotencyKey = requestId(body.request_id || req.get('Idempotency-Key'));
  const occurredAt = body.occurred_at ? new Date(body.occurred_at) : new Date();

  if (!STRICT_UUID_RE.test(periodId) || !STRICT_UUID_RE.test(studentId)) {
    return res.status(400).json({ error: '課期或學員識別碼格式不正確', code: 'INPUT_INVALID' });
  }
  if (!reason) return res.status(400).json({ error: '請填寫扣課原因', code: 'REASON_REQUIRED' });
  if (Number.isNaN(occurredAt.getTime())) {
    return res.status(400).json({ error: '扣課時間格式不正確', code: 'OCCURRED_AT_INVALID' });
  }

  const by = text(req.adminUser?.name || req.adminUser?.username || req.adminUser?.sub || 'unknown', 120);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 先以無鎖讀取教練，取得與 /api/slots/:id/book 完全相同的 advisory lock。
    // 不可先 FOR UPDATE course_period 再等 coach lock：選槽路徑已持有 coach lock
    // 並在 INSERT session 時取得 course_period 的 FK KEY SHARE，會形成死鎖。
    const periodHintResult = await client.query(
      `SELECT id, coach_id FROM course_periods WHERE id = $1`,
      [periodId]
    );
    const periodHint = periodHintResult.rows[0];
    if (!periodHint) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: '找不到課期', code: 'PERIOD_NOT_FOUND' });
    }
    if (!periodHint.coach_id) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: '此課期缺少教練資訊，暫時不可手動扣課', code: 'PERIOD_COACH_MISSING' });
    }
    await client.query(
      `SELECT pg_advisory_xact_lock(hashtext($1))`,
      [String(periodHint.coach_id)]
    );

    // 取得教練 lock 後才鎖 period；接下來的容量檢查 + 建 session 與選槽序列化。
    const pr = await client.query(
      `SELECT cp.id, cp.venue_id, cp.coach_id, cp.total_sessions, cp.used_sessions,
              cp.admin_enrollment_id, cp.group_order_id, cp.status
         FROM course_periods cp
        WHERE cp.id = $1
        FOR UPDATE`,
      [periodId]
    );
    const period = pr.rows[0];
    if (!period) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: '找不到課期', code: 'PERIOD_NOT_FOUND' });
    }
    if (String(period.coach_id || '') !== String(periodHint.coach_id)) {
      // 極少數「剛好改派教練」競態：不要以舊教練 lock 處理新教練課期；回覆可安全重試。
      await client.query('ROLLBACK');
      return res.status(409).json({ error: '課期教練剛更新，請重新整理後再操作', code: 'PERIOD_COACH_CHANGED_RETRY' });
    }
    if (!isVenueInScope(req, period.venue_id)) {
      await client.query('ROLLBACK');
      return res.status(403).json({ error: '此課期不在您的場館範圍內', code: 'VENUE_OUT_OF_SCOPE' });
    }
    if (period.status !== 'active') {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: '此課期目前不可扣課', code: 'PERIOD_NOT_ACTIVE' });
    }

    const activeMembers = await client.query(
      `SELECT student_id
         FROM course_period_enrollments
        WHERE course_period_id = $1 AND status = 'active'
        FOR SHARE`,
      [periodId]
    );
    if (period.group_order_id || activeMembers.rowCount > 1) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        error: '此為共享課期；請由簽到驗證處理整班出席，避免影響其他團購成員的堂數',
        code: 'SHARED_PERIOD_REQUIRES_CHECKIN',
      });
    }

    const prior = await client.query(
      `SELECT id FROM manual_lesson_deductions
        WHERE course_period_id = $1 AND request_id = $2
        FOR UPDATE`,
      [periodId, idempotencyKey]
    );
    if (prior.rowCount) {
      const deduction = await readDeduction(client, periodId, prior.rows[0].id);
      await client.query('COMMIT');
      return res.json({ ok: true, idempotent: true, deduction });
    }

    const membership = await client.query(
      `SELECT s.id, s.name
         FROM course_period_enrollments cpe
         JOIN students s ON s.id = cpe.student_id
        WHERE cpe.course_period_id = $1
          AND cpe.student_id = $2
          AND cpe.status = 'active'
        FOR SHARE`,
      [periodId, studentId]
    );
    if (!membership.rowCount) {
      await client.query('ROLLBACK');
      return res.status(403).json({ error: '此學員不屬於可扣課的課期', code: 'STUDENT_NOT_IN_PERIOD' });
    }

    const usage = await client.query(
      `SELECT
         COUNT(DISTINCT cs.id) FILTER (WHERE cs.status::text NOT LIKE 'cancelled%')::int AS reserved_sessions,
         COUNT(DISTINCT cs.id) FILTER (
           WHERE cs.status::text NOT LIKE 'cancelled%'
             AND cr.course_session_id IS NOT NULL
         )::int AS attended_sessions
         FROM course_sessions cs
    LEFT JOIN checkin_records cr ON cr.course_session_id = cs.id
        WHERE cs.course_period_id = $1`,
      [periodId]
    );
    const reserved = Number(usage.rows[0]?.reserved_sessions) || 0;
    const attended = Number(usage.rows[0]?.attended_sessions) || 0;
    const total = Number(period.total_sessions) || 0;
    // 可再排／可再補登的堂數以「所有未取消 session」計算，不能只看已簽到數；
    // 已排而尚未簽到的 session 已保留一堂，否則後續簽到會使課期超額。
    const remainingBefore = Math.max(0, total - reserved);
    if (remainingBefore < 1) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: '剩餘堂數不足，無法扣課', code: 'INSUFFICIENT_SESSIONS' });
    }

    const session = await client.query(
      `INSERT INTO course_sessions
         (course_period_id, coach_id, scheduled_at, duration_minutes, status, completed_at)
       VALUES ($1, $2, $3, 60, 'completed', NOW())
       RETURNING id`,
      [periodId, period.coach_id || null, occurredAt.toISOString()]
    );
    const courseSessionId = session.rows[0].id;
    await client.query(
      `INSERT INTO checkin_records
         (course_session_id, student_id, checked_in_by_student_id,
          is_auto_linked, checked_in_source, checked_in_at)
       VALUES ($1, $2, $2, FALSE, 'staff', $3)`,
      [courseSessionId, studentId, occurredAt.toISOString()]
    );

    const remainingAfter = remainingBefore - 1;
    const ledger = await client.query(
      `INSERT INTO manual_lesson_deductions
         (request_id, course_period_id, admin_enrollment_id, course_session_id, student_id,
          venue_id, quantity, remaining_before, remaining_after, reason, deducted_by)
       VALUES ($1,$2,$3,$4,$5,$6,1,$7,$8,$9,$10)
       RETURNING id`,
      [
        idempotencyKey, periodId, period.admin_enrollment_id || null, courseSessionId, studentId,
        period.venue_id, remainingBefore, remainingAfter, reason, by,
      ]
    );

    // Legacy counters are deliberately derived from the authoritative checkin count,
    // never decremented below zero and never allowed to exceed the purchased total.
    await client.query(
      `UPDATE course_periods
          SET used_sessions = $2, updated_at = NOW()
        WHERE id = $1`,
      [periodId, Math.min(total, attended + 1)]
    );
    if (period.admin_enrollment_id) {
      const updatedEnrollment = await client.query(
        `UPDATE admin_enrollments
            SET used_sessions = LEAST(COALESCE(NULLIF(total_sessions, 0), $2),
                                      GREATEST(COALESCE(used_sessions, 0), $2)),
                updated_at = NOW()
          WHERE id = $1
          RETURNING id`,
        [period.admin_enrollment_id, Math.min(total, attended + 1)]
      );
      if (updatedEnrollment.rowCount) {
        await client.query(
          `INSERT INTO admin_enrollment_audit_logs (enrollment_id, action, by_user, reason)
           VALUES ($1,$2,$3,$4)`,
          [
            period.admin_enrollment_id,
            `手動扣課 1 堂（學員：${membership.rows[0].name}；剩餘 ${remainingAfter} 堂）`,
            by,
            reason,
          ]
        );
      }
    }

    const deduction = await readDeduction(client, periodId, ledger.rows[0].id);
    await client.query('COMMIT');
    res.status(201).json({ ok: true, idempotent: false, deduction });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    // A unique conflict can only occur if another client created the same request
    // between lock acquisition and insert (for example a legacy worker); surface a
    // retry-safe conflict instead of pretending a second deduction succeeded.
    if (err?.code === '23505') {
      try {
        const existing = await pool.query(
          `SELECT d.*, s.name AS student_name
             FROM manual_lesson_deductions d
             LEFT JOIN students s ON s.id = d.student_id
            WHERE d.course_period_id = $1 AND d.request_id = $2`,
          [periodId, idempotencyKey]
        );
        if (existing.rowCount) {
          return res.json({ ok: true, idempotent: true, deduction: publicRow(existing.rows[0]) });
        }
      } catch { /* fall through to the explicit conflict */ }
      return res.status(409).json({ error: '重複扣課請求，請重新整理後確認堂數', code: 'IDEMPOTENCY_CONFLICT' });
    }
    console.error('[admin/manual-deductions create]', err);
    res.status(500).json({ error: '手動扣課失敗，尚未扣除堂數', code: 'MANUAL_DEDUCTION_FAILED' });
  } finally {
    client.release();
  }
});

router._internals = {
  requestId,
  publicRow,
  STRICT_UUID_RE,
};

module.exports = router;
