// Object Storage driver 選擇契約：不連線 bucket、不寫檔，只以獨立 Node process
// 載入 module，避免 require cache 與本機環境變數互相污染。
const assert = require('assert');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const modulePath = path.join(ROOT, 'server/services/objectStorage');
const STORAGE_ENV_KEYS = [
  'NODE_ENV',
  'OBJECT_STORAGE_DRIVER',
  'OBJECT_STORAGE_BUCKET_ID',
  'REPLIT_OBJECT_STORAGE_BUCKET',
];

function driverFor(overrides = {}) {
  const env = { ...process.env };
  for (const key of STORAGE_ENV_KEYS) delete env[key];
  Object.assign(env, overrides);

  const result = spawnSync(
    process.execPath,
    ['-e', `process.stdout.write(require(${JSON.stringify(modulePath)}).driverName)`],
    { cwd: ROOT, env, encoding: 'utf8' }
  );
  assert.strictEqual(result.status, 0, result.stderr || 'objectStorage failed to load');
  return result.stdout.trim();
}

assert.strictEqual(driverFor(), 'local', '未設定時 local 開發應使用 local driver');
assert.strictEqual(
  driverFor({ NODE_ENV: 'development', REPLIT_OBJECT_STORAGE_BUCKET: 'configured-bucket' }),
  'local',
  'local 開發即使有 bucket 設定也不可意外切換 driver'
);
assert.strictEqual(
  driverFor({ NODE_ENV: 'production', REPLIT_OBJECT_STORAGE_BUCKET: 'configured-bucket' }),
  'replit',
  'production 有 Replit bucket 時必須使用 shared storage'
);
assert.strictEqual(
  driverFor({ NODE_ENV: 'production', OBJECT_STORAGE_BUCKET_ID: 'alternate-bucket-id' }),
  'replit',
  '指定非預設 bucket 時 production 必須使用 Replit driver'
);
assert.strictEqual(
  driverFor({ NODE_ENV: 'production', REPLIT_OBJECT_STORAGE_BUCKET: 'configured-bucket', OBJECT_STORAGE_DRIVER: 'local' }),
  'local',
  '明確 local override 保留給受控的故障排查情境'
);
assert.strictEqual(
  driverFor({ NODE_ENV: 'development', OBJECT_STORAGE_DRIVER: 'replit' }),
  'replit',
  '明確 replit override 應可供整合測試使用'
);

console.log('object_storage_driver_test: PASS');
